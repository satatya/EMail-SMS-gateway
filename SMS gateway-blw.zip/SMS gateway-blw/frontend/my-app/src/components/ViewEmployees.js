import React, { useEffect, useState } from 'react';
import { Table, Button } from 'react-bootstrap';

function ViewEmployees() {
    const [employees, setEmployees] = useState([]);

    useEffect(() => {
        async function fetchData() {
            const response = await fetch('http://127.0.0.1:5000/employees');
            const data = await response.json();
            setEmployees(data);
        }
        fetchData();
    }, []);

    return (
        <div className="container mt-5">
            <h2>View Employees</h2>
            <Table striped bordered hover responsive className="mt-3">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Location</th>
                        <th>Date of Birth</th>
                        <th>Date of Retirement</th>
                    </tr>
                </thead>
                <tbody>
                    {employees.map((employee) => (
                        <tr key={employee[0]}>
                            <td>{employee[0]}</td>
                            <td>{employee[1]}</td>
                            <td>{employee[2]}</td>
                            <td>{employee[3]}</td>
                            <td>{employee[4]}</td>
                            <td>{employee[5]}</td>
                            <td>{employee[6]}</td>
                        </tr>
                    ))}
                </tbody>
            </Table>
        </div>
    );
}

export default ViewEmployees;
