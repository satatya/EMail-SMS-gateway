import React, { useState, useEffect } from 'react';
import { Container, Card, Button, Row, Col } from 'react-bootstrap';

function TodaysBirthdays() {
    const [employees, setEmployees] = useState([]);

    useEffect(() => {
        fetch('http://127.0.0.1:5000/birthdays')
            .then(response => response.json())
            .then(data => setEmployees(data))
            .catch(error => console.error('Error fetching data:', error));
    }, []);

    const handleSendSMS = (phone) => {
        // Logic to send SMS
        alert(`SMS sent to ${phone}`);
    };

    const handleSendEmail = (email) => {
        // Logic to send email
        alert(`Email sent to ${email}`);
    };

    return (
        <Container>
            <h2 className="my-4">Today's Birthdays</h2>
            {employees.length > 0 ? (
                <Row>
                    {employees.map(employee => (
                        <Col key={employee[0]} sm={12} md={6} lg={4} className="mb-4">
                            <Card>
                                <Card.Body>
                                    <Card.Title>{employee[1]}</Card.Title>
                                    <Card.Text>
                                        <strong>Phone:</strong> {employee[2]}<br />
                                        <strong>Email:</strong> {employee[3]}
                                    </Card.Text>
                                    <Button variant="primary" onClick={() => handleSendSMS(employee[2])}>Send SMS</Button>{' '}
                                    <Button variant="secondary" onClick={() => handleSendEmail(employee[3])}>Send Email</Button>
                                </Card.Body>
                            </Card>
                        </Col>
                    ))}
                </Row>
            ) : (
                <p>No birthdays today.</p>
            )}
        </Container>
    );
}

export default TodaysBirthdays;
