import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { Navbar, Nav, Container } from 'react-bootstrap';
import EmployeeForm from './components/EmployeeForm';
import ViewEmployees from './components/ViewEmployees';
import TodaysBirthdays from './components/TodaysBirthdays';
import TodaysRetirements from './components/TodaysRetirements';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
    return (
        <Router>
            <div className="app">
                <Container className="text-center mt-3">
                    <h1>Employee Management System</h1>
                </Container>
                <Navbar bg="primary" variant="dark" expand="lg" className="mt-3">
                    <Container>
                        <Navbar.Brand href="/">EMS</Navbar.Brand>
                        <Navbar.Toggle aria-controls="basic-navbar-nav" />
                        <Navbar.Collapse id="basic-navbar-nav">
                            <Nav className="me-auto">
                                <Nav.Link as={Link} to="/">Home</Nav.Link>
                                <Nav.Link as={Link} to="/view">View Employees</Nav.Link>
                                <Nav.Link as={Link} to="/birthdays">Today's Birthdays</Nav.Link>
                                <Nav.Link as={Link} to="/retirements">Today's Retirements</Nav.Link>
                            </Nav>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>
                <Container className="mt-3">
                    <Routes>
                        <Route path="/" element={<EmployeeForm />} />
                        <Route path="/view" element={<ViewEmployees />} />
                        <Route path="/birthdays" element={<TodaysBirthdays />} />
                        <Route path="/retirements" element={<TodaysRetirements />} />
                    </Routes>
                </Container>
            </div>
        </Router>
    );
}

export default App;
