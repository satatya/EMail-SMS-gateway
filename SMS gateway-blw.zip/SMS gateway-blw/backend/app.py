from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import sqlite3
import os
from datetime import datetime

app = Flask(__name__, static_folder='../frontend/my-app/build')
CORS(app)

def init_sqlite_db():
    conn = sqlite3.connect('employee.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS employees (
                        id INTEGER PRIMARY KEY,
                        name TEXT NOT NULL,
                        phone TEXT NOT NULL,
                        email TEXT NOT NULL,
                        location TEXT NOT NULL,
                        dob DATE NOT NULL,
                        retirement DATE NOT NULL,
                        UNIQUE(phone, email)
                    )''')
    conn.commit()
    conn.close()

init_sqlite_db()

@app.route('/add_employee', methods=['POST'])
def add_employee():
    data = request.get_json()
    
    name = data['name']
    phone = data['phone']
    email = data['email']
    location = data['location']
    dob = data['dob']
    retirement = data['retirement']
    
    try:
        conn = sqlite3.connect('employee.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO employees (name, phone, email, location, dob, retirement) VALUES (?, ?, ?, ?, ?, ?)',
                       (name, phone, email, location, dob, retirement))
        conn.commit()
        conn.close()
        return jsonify({'status': 'success'})
    except sqlite3.IntegrityError:
        return jsonify({'status': 'error', 'message': 'Duplicate email or phone number'}), 400

@app.route('/employees', methods=['GET'])
def get_employees():
    conn = sqlite3.connect('employee.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM employees')
    rows = cursor.fetchall()
    conn.close()
    return jsonify(rows)

@app.route('/birthdays', methods=['GET'])
def get_birthdays():
    conn = sqlite3.connect('employee.db')
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM employees
                      WHERE strftime('%d', dob) = strftime('%d', 'now')
                      AND strftime('%m', dob) = strftime('%m', 'now')''')
    rows = cursor.fetchall()
    conn.close()
    return jsonify(rows)

@app.route('/retirements', methods=['GET'])
def get_retirements():
    conn = sqlite3.connect('employee.db')
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM employees
                      WHERE strftime('%d', retirement) = strftime('%d', 'now')
                      AND strftime('%m', retirement) = strftime('%m', 'now')''')
    rows = cursor.fetchall()
    conn.close()
    return jsonify(rows)

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')

@app.route('/delete_employee/<int:id>', methods=['DELETE'])
def delete_employee(id):
    conn = sqlite3.connect('employee.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM employees WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return jsonify({'message': f'Employee with ID {id} deleted successfully'})

if __name__ == '__main__':
    app.run(debug=True)
